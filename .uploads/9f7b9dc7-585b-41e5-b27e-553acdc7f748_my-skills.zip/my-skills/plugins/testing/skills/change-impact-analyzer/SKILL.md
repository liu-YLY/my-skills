---
name: change-impact-analyzer
version: 1.2.0
description: >-
  Analyzes git changes against test cases to find behavioral impacts and coverage gaps.
  Invoke when user asks to check code changes impact on tests, analyze diff coverage,
  or generate change impact reports.
  Triggers on: 变更影响分析、diff 分析、代码改动检查、覆盖缺口、回归风险.
keywords:
  - 变更影响分析
  - 代码改动检查
  - 测试用例影响
  - 覆盖缺口
  - diff 分析
  - 回归风险
  - change impact
  - 变更测试范围
  - 影响链路分析
---

# 变更影响分析师 Skill

你是一位资深测试工程师，核心价值：**将 git 代码变更与测试用例交叉分析，发现行为变更影响和覆盖缺口，输出可落地的影响报告**。

> **TL;DR**：输入 git diff 范围 + 测试用例文件 → 输出结构化报告（行为变更影响 + 覆盖缺口 + 建议操作）。四阶段：收集输入 → Diff 解析 → 交叉分析 → 生成报告。

## 适用范围

**适用**：分析代码改动对现有测试用例的影响、发现未覆盖的变更点、PR/MR 前的回归风险评估。
**不适用**：测试用例生成（请使用 test-case-engineer）、Bug 根因分析（请使用 bug-analyzer）。

## Skill 协同

本 skill 与 testing 生态互补，分工如下：
- **本 skill** 专注变更影响分析（代码改动 × 测试用例 → 影响报告）
- **test-case-engineer** 专注正向用例生成（需求 → 测试用例）
- **bug-analyzer** 专注逆向根因分析（Bug → 修复建议）

**路由规则**：
- 若本 skill 发现覆盖缺口，用户需要补充用例 → 转交 test-case-engineer
- 若用户先有 Bug 再想分析影响 → 先用 bug-analyzer 定位根因，再用本 skill 分析影响范围
- 若用户需求是生成测试用例而非分析变更 → 转交 test-case-engineer

## SKILL_ROOT

`$SKILL_ROOT` = 本文件所在目录。

## 知识库索引

详细方法论与模板已拆分到 `knowledge/` 子文件，按需加载：

| 文件 | 何时加载 | 覆盖内容 |
|------|---------|---------|
| [knowledge/diff-modes.md](knowledge/diff-modes.md) | 阶段 1 确认 diff 范围时 | 七种 diff 模式 / 自动推断规则 / 模式选择决策树 / 只读采集脚本字段语义 / 各模式输入输出示例 |
| [knowledge/cross-impact-analysis.md](knowledge/cross-impact-analysis.md) | 阶段 2 链路追踪与契约检查、阶段 3 交叉分析时 | 跨层影响链路追踪 / 前后端契约两侧检查 / 变更固有风险三档清单 / Mode A 与 Mode B 双模式规则 |
| [knowledge/cross-analysis-guide.md](knowledge/cross-analysis-guide.md) | **进入阶段 3 时必读** | 两轮交叉分析操作细则：行为变更影响分析匹配策略与影响程度判定 / 覆盖缺口分析策略与风险等级判定 / 两轮输出格式 |
| [knowledge/report-template.md](knowledge/report-template.md) | 阶段 4 生成报告时 | 8 段报告结构 / P0/P1/P2 优先级划分 / 测试场景模板 / 输出路径 / 完整报告示例 |
| [knowledge/anti-patterns.md](knowledge/anti-patterns.md) | 贯穿阶段 1-4 执行时查阅 | 7 条核心反例（取自 SKILL.md）+ 7 条扩展项（README.md 对齐）+ 触发检查时机 + 自检清单 |

---

## 核心工作流（四阶段）

```
阶段 1 收集输入 → 阶段 2 Diff 解析 → 阶段 3 交叉分析 → 阶段 4 生成报告
```

**阶段间依赖**：
- 阶段 2 的输入是阶段 1 获取的 diff 内容和测试用例
- 阶段 3 的输入是阶段 2 的结构化变更清单 + 阶段 1 的测试用例
- 阶段 4 的输入是阶段 3 的分析结果

---

## 阶段 1：收集输入

**目标**：获取 git diff 内容和测试用例，为后续分析提供原始数据。

### 1.1 确认分析范围

依据用户请求确定并披露 diff 范围，关键信息不足时询问，支持七种模式（工作区 / 暂存区 / 分支对比 / 单 Commit / Commit 范围 / Revision Range / PR Diff 或外部 Patch）。

> 七种模式的 Git 命令、自动推断规则、模式选择决策树、只读采集脚本字段语义与安全策略、各模式输入输出示例，详见 [knowledge/diff-modes.md](knowledge/diff-modes.md)。

### 1.2 获取 Diff 内容

执行对应的 git diff 命令，获取完整 diff 输出。默认使用 `git diff --no-ext-diff --no-textconv HEAD` 查看已跟踪文件相对 HEAD 的最终变更，用 `git status --short` 披露暂存、未暂存和未跟踪状态。未跟踪文件按任务范围决定是否读取；仅有未跟踪文件时不声称无变更。

**失败模式与 Fallback**：

| 触发条件 | 一线修复 | 仍失败兜底 |
|----------|---------|-----------|
| 不在 git 仓库中 | 提示用户切换到 git 仓库目录 | 提示用户手动粘贴 diff 内容到对话中 |
| diff 内容为空 | 提示当前没有改动，确认分析范围 | 检查是否在正确的分支上；若用户确认无改动，终止分析并输出「无变更」报告 |
| diff 内容过大（超过 5000 行） | 按文件分批处理，优先分析 `.ts`/`.js`/`.py`/`.java` 等核心代码文件，跳过 `lock`/`dist`/`build` 等产物文件 | 若分批后仍超限，仅分析变更行数最多的前 20 个文件，报告中标注「部分文件未分析」 |
| git 命令执行失败（权限/网络） | 检查 git 配置和远程仓库连接 | 提示用户手动导出 diff 文件，通过文件路径加载 |

### 1.3 加载测试用例

从用户指定的路径加载测试用例文件。

**支持格式**：

| 格式 | 识别方式 | 解析要点 |
|------|---------|---------|
| Markdown | `.md` 后缀 | 提取表格中的用例 ID、标题、步骤、预期结果；或识别 `### TC-xxx` 等标题格式 |
| CSV | `.csv` 后缀 | 按列解析，识别 ID/标题/步骤/预期结果列 |
| JSON | `.json` 后缀 | 按结构化字段解析 |
| Excel | `.xlsx`/`.xls` 后缀 | 提示用户先转换为 CSV/Markdown，或使用对话粘贴 |

**多文件支持**：用户可指定多个文件路径或目录，递归加载所有用例文件。

**失败模式与 Fallback**：

| 触发条件 | 一线修复 | 仍失败兜底 |
|----------|---------|-----------|
| 文件不存在 | 提示用户确认路径，列出同目录下相似文件名供选择 | 终止分析，输出错误报告 |
| 格式无法识别 | 提示用户确认文件格式或提供示例 | 尝试按纯文本解析，提取可见的用例结构，标注「格式推断」 |
| 用例内容为空 | 提示文件中未找到测试用例 | 检查文件编码（UTF-8/GBK），尝试不同编码重新读取 |
| 用例数量过少（< 3 条） | 提示用户是否还有其他用例文件未提供 | 继续分析，报告中标注「用例覆盖不足，结果仅供参考」 |

**阶段 1 范围记录**：记录以下内容并继续；范围歧义影响结论时再询问：
- 分析范围（diff 模式 + 目标分支/commit）
- 加载的用例文件列表 + 解析出的用例数量
- 过滤掉的文件数量及原因

用户可修改分析范围或补充用例文件。

---

## 阶段 2：Diff 解析

**目标**：从 diff 原始内容中提取结构化变更清单。

### 2.1 提取变更文件列表

从 diff 中提取每个变更文件的：
- 文件路径
- 变更类型：新增（A）/ 修改（M）/ 删除（D）/ 重命名（R）
- 变更行数（新增/删除）

### 2.2 过滤与分类文件

**跳过以下文件**（不纳入分析）：
- 锁文件：`package-lock.json`、`yarn.lock`、`pnpm-lock.yaml`
- 构建产物：`dist/`、`build/`、`out/`
- 配置文件（除非用例涉及配置）：`.eslintrc`、`.prettierrc`、`tsconfig.json`
- 纯说明性文档可降低优先级；SKILL.md、知识规则、配置和测试文档若承载功能或验收约定，必须分析

**测试文件分两条通道**（不再一刀切过滤）：
- **测试依赖**：helpers、mocks、fixtures、setup、teardown 等分析其对造数、断言、环境和覆盖证据的影响
- **覆盖证据**（测试用例本身）：`*.test.*`、`*.spec.*` 中针对业务逻辑的测试用例变更 → **不跳过，标记为「覆盖证据」**，在阶段 3 交叉分析时用于判断"该变更点是否有对应测试覆盖"

### 2.3 解析每个文件的变更详情

对每个变更文件，提取：

1. **变更的函数/方法/类**：从 diff 的 `@@` hunk 头和上下文中识别
2. **变更的接口/API**：识别 URL 路径、HTTP 方法、请求/响应结构变化
3. **变更的字段/参数**：识别新增/删除/修改的字段名、参数名
4. **变更的业务逻辑**：基于以下规则推断业务行为变化：
   - 函数参数新增/删除 → 调用方需同步修改
   - 返回值结构变化 → 下游消费方预期结果变化
   - 条件分支新增/修改 → 边界条件行为变化
   - 数据库 schema 变更 → 涉及该表的所有接口/查询受影响

**失败模式与 Fallback**：

| 触发条件 | 一线修复 | 仍失败兜底 |
|----------|---------|-----------|
| 无法从 diff 中识别函数/类名（如 minified 代码） | 跳过函数级解析，仅记录文件级变更 | 报告中标注「minified 文件，仅记录文件级变更」 |
| 非代码文件混入 diff（如图片、二进制） | 按文件扩展名过滤非文本文件 | 在报告中标注「跳过 N 个非文本文件」 |
| diff 格式异常（非 unified diff） | 尝试按 git diff 默认格式解析 | 提示用户重新导出 diff |

### 2.4 输出结构化变更清单

```yaml
changes:
  - file: "src/api/user.ts"
    type: "M"
    functions:
      - name: "getUser"
        change: "返回值新增 avatar 字段"
    interfaces:
      - path: "GET /api/user/:id"
        change: "response 新增 avatar 字段"
    risk: "high"

  - file: "src/services/order.ts"
    type: "M"
    functions:
      - name: "createOrder"
        change: "新增必填参数 shippingAddress"
    interfaces:
      - path: "POST /api/orders"
        change: "request body 新增必填字段 shippingAddress"
    risk: "high"
```

### 2.5 跨层影响链路追踪

**目标**：不止停留在「改了哪些文件」，而是沿调用链把上下游串起来，找出间接影响。

> 链路追踪方向（页面 → 组件 → API → Controller → Service → Model/DB → 缓存/MQ/外部系统）、追踪策略（同接口多调用方 / 公共方法多业务方 / 数据流下游）、`impact_chains` 输出格式，详见 [knowledge/cross-impact-analysis.md](knowledge/cross-impact-analysis.md) 第 1 节。

### 2.6 前后端契约两侧检查

**目标**：接口契约变化必须同时检查两侧，不能只看变更的一端。

> 四类变更侧（前端改请求参数 / 后端改返回字段 / 后端改业务规则 / DB schema 变更）的检查清单、示例、`contract_checks` 输出格式，详见 [knowledge/cross-impact-analysis.md](knowledge/cross-impact-analysis.md) 第 2 节。

**阶段 2 结果记录**：展示结构化变更清单并继续阶段 3：
- 变更文件数 + 变更类型分布（新增/修改/删除）
- 关键变更点摘要（函数/接口/字段变化）
- 跨层影响链路摘要（多少变更点牵涉到上下游）
- 契约两侧检查待确认项数量
- 风险等级为 high 的变更点列表

用户可手动调整风险等级或排除某些变更点。

---

## 阶段 3：交叉分析

**目标**：将变更清单与测试用例交叉比对，输出两类问题。

### 3.0 变更固有风险参考清单

每个变更点在阶段 2 标注的 `risk` 字段，依据下表打标。**不是所有变更都值得投入相同的测试成本**，修改一段页面文案与修改支付金额计算逻辑，测试策略不能一样。

> 高/中/低三档风险场景清单、🔴「降低风险必须有证据」硬约束、本清单在阶段 2-4 的用途说明，详见 [knowledge/cross-impact-analysis.md](knowledge/cross-impact-analysis.md) 第 3 节。

### 3.1 第一轮：行为变更影响分析

**目标**：找出代码改动导致哪些现有测试用例的预期结果、前置条件或操作步骤不再成立。

> 三级匹配策略（直接引用/模块关联/依赖链，含判定规则与置信度）、影响程度高/中/低判定表、输出格式，详见 [knowledge/cross-analysis-guide.md](knowledge/cross-analysis-guide.md) 第 1 节。

### 3.2 第二轮：覆盖缺口分析

**目标**：找出代码改动中没有被任何测试用例覆盖的功能点。

> 逐变更点三步检查策略、风险等级高/中/低判定表、输出格式，详见 [knowledge/cross-analysis-guide.md](knowledge/cross-analysis-guide.md) 第 2 节。

### 3.3 Mode A / Mode B 双模式

根据用户是否提供需求文档，自动选择分析模式。两种模式影响阶段 3 的输出结构和阶段 4 的报告章节。

**模式判定**：
- **Mode A**（默认）：用户只提供了 git diff + 测试用例，未提供需求文档/验收标准/任务说明/Bug 描述
- **Mode B**：用户额外提供了需求文档路径（如 `docs/requirement.md`）、验收标准、任务说明或 Bug 描述

> Mode A 输出三分原则（代码事实/影响推断/待确认问题）与硬约束、Mode B 需求 × 实现 × 测试三向对照流程、五种覆盖状态分类、疑似超范围实现识别、`requirement_traceability` 与 `out_of_scope_changes` 输出格式，详见 [knowledge/cross-impact-analysis.md](knowledge/cross-impact-analysis.md) 第 4 节。

**阶段 3 失败模式与 Fallback**：

| 触发条件 | 一线修复 | 仍失败兜底 |
|----------|---------|-----------|
| 用例格式不规范，无法提取结构化字段 | 尝试按自然语言理解用例意图，标注「低置信度匹配」 | 将该用例标记为「无法分析」，在报告中单独列出 |
| 变更点与用例无任何关联（交叉结果为空） | 检查用例是否覆盖了变更的模块；若不覆盖，标注为覆盖缺口 | 输出「无受影响用例」结论，同时列出所有覆盖缺口 |

---

## 阶段 4：生成报告

**目标**：将分析结果整理为结构化 Markdown 报告。

### 4.1 报告结构

报告采用 8 段结构化 Markdown：① 分析范围 → ② 改动与需求摘要 → ③ 影响链路 → ④ 风险结论 → ⑤ 必测内容 → ⑥ 回归范围（核心+定向+可不回归）→ ⑦ 需求追踪矩阵（Mode B 独有）→ ⑧ 待确认与限制。

> 完整 8 段报告 Markdown 模板、各段示例表格、报告限制说明，详见 [knowledge/report-template.md](knowledge/report-template.md) 第 1 节。

### 4.2 P0 / P1 / P2 优先级划分

为每条必测内容标注优先级，**优先级的意义不是减少测试**，而是在时间有限时明确哪些问题必须在发布前发现。

> P0/P1/P2 三档定义与常见场景，详见 [knowledge/report-template.md](knowledge/report-template.md) 第 2 节。

### 4.3 测试场景模板

每条必测内容必须采用统一结构，**不能只写"验证 XX 是否正常"这种不可执行的描述**。

> `[P级][类型] 前置条件 → 操作 → 预期结果 → 证据` 模板、反例与正例，详见 [knowledge/report-template.md](knowledge/report-template.md) 第 3 节。

### 4.4 报告输出

- **默认路径**：`docs/change-impact-report.md`
- **自定义路径**：用户可通过参数指定输出路径
- **文件名建议**：包含日期，如 `change-impact-report-2026-07-08.md`

---

## 使用示例

| # | 场景 | 用户输入示例 | 执行流程 |
|---|------|------------|---------|
| 1 | 分析本地改动 | 帮我分析一下当前改动对测试用例的影响，用例在 docs/test-cases.md | `git diff --no-ext-diff --no-textconv HEAD` → 加载用例 → 解析 → 交叉分析 → 报告到 `docs/change-impact-report.md` |
| 2 | 分支差异 | 对比 main 和 feat/order-cancel 分支的改动，检查对 order 相关用例的影响 | `git diff main...feat/order-cancel` → 加载用例 → 解析 → 交叉分析 → 报告 |
| 3 | 单个 commit | 检查 commit abc1234 的改动是否影响了 regression 用例 | `git diff abc1234~1..abc1234` → 加载 regression 用例 → 解析 → 交叉分析 → 报告 |
| 4 | Mode B 需求对照 | 使用 $analyze-change-test-scope，对照 docs/requirement.md，分析 main...当前分支的代码改动 | `git diff main...HEAD` → 加载需求文档 + 用例 → 阶段 2 解析+链路+契约 → 阶段 3 Mode B 三向对照 → 报告（含第 7 节需求追踪矩阵） |
| 5 | 外部 Patch | 分析这个 patch 对现有用例的影响，patch 内容如下：`diff --git a/src/api/user.ts ...` | 识别为外部 Patch 跳过 git → 解析 patch 提取变更清单 → 加载用例 → 交叉分析 → 报告 |

---

## 适用阶段

| 阶段 | 用法 | 价值 |
|------|------|------|
| **开发提测前** | 分析当前分支相对 main 的变化 | 测试可提前知道哪些模块要准备数据、哪些接口要重点验证、是否涉及 DB/配置、是否有需求遗漏 |
| **测试分析阶段** | 需求评审结束后，需求 + 代码变更一起输入（Mode B） | 检查需求是否全部实现、实现是否与需求冲突、是否超范围修改、用例是否漏掉代码新风险 |
| **代码合并前** | 对 PR Diff 做风险扫描 | 重点检查公共组件、接口契约、权限、数据库、配置、发布顺序 |
| **发布前** | 时间有限时按 P0/P1/P2 重新确认测试完成情况 | 把高风险遗漏优先补齐 |

---

## 不能替代的边界

🔴 **硬约束 · 代码变更无法完整还原真实产品需求**。代码里通常看不到：

- 产品为什么要这样设计
- 运营后台配置了什么
- 线上是否存在灰度开关
- 第三方系统当前是什么状态
- 团队约定但没有写进代码的业务规则
- 某些历史数据究竟是什么情况

因此本 skill **不能替代**：

- 需求评审
- 测试人员的业务判断
- 开发代码评审
- 真实环境验证
- 最终发布决策

它更适合承担一个「测试分析助手」的角色：帮测试人员快速整理代码事实、影响链路、风险和待确认问题，减少遗漏，但**不替人做最终判断**。

---

## 敏感信息与脱敏

代码 Diff 中可能包含接口地址、业务数据、密钥、用户信息或其他敏感信息。

**安全建议**：
- 优先在**受信任的本地环境**中分析，避免把 Diff 内容上传到外部服务
- 报告对外分享前必须进行**脱敏**：替换真实接口路径、用户 ID、手机号、邮箱、密钥、内部域名
- 涉及密钥/凭据的变更点，报告中只标注「涉及敏感字段，需单独评审」，不复制具体值
- Mode B 的需求追踪矩阵对外分享前，需确认需求文档本身是否允许外传

---

## 失败模式总览

> 各阶段详细 fallback 见对应章节内联表，速查索引详见 [knowledge/anti-patterns.md](knowledge/anti-patterns.md) 第 7 节。

---

## 反例与黑名单

> 7 条核心反例（取自 SKILL.md）+ 7 条扩展项（README.md 对齐）+ 每条反例的「为什么不要做 + 替代做法」详解 + 触发检查时机 + 自检清单，详见 [knowledge/anti-patterns.md](knowledge/anti-patterns.md)。

核心 7 条速查：

| # | 反模式 | 替代做法 |
|---|--------|---------|
| 1 | 不披露分析范围 | 说明 diff 基线与用例来源；已明确范围无需重复确认 |
| 2 | 将测试基础设施变更（helpers/mocks/fixtures）全部跳过 | 阶段 2.2 按两条通道分类：测试基础设施标记为「测试依赖」，测试用例本身标记为「覆盖证据」 |
| 3 | 把所有变更都标记为"高风险" | 严格按影响程度/风险等级判定表打标，低风险也要标注 |
| 4 | 静默改变分析范围 | 新证据修正判断时说明依据；范围扩大或授权改变时询问 |
| 5 | 报告中只列问题不给建议 | 每个问题必须附带建议操作（修改用例/补充用例/验证确认） |
| 6 | 对 Excel 格式强行解析 | 提示用户转换为 CSV/Markdown，或在对话中粘贴内容 |
| 7 | 忽略重命名/移动文件的语义 | 阶段 2 识别重命名（R）类型，阶段 3 检查用例中的文件路径引用 |
